<?php exit;

$menu['setting']['tab'] += array (			
	'wxstbw'=>array('url'=>url('setting-wxstbw'), 'text'=>'文本盲水印')
);

?>